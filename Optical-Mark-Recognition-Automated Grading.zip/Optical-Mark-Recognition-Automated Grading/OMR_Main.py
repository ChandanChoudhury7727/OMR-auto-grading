import cv2
import numpy as np
import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
import pandas as pd
import utlis
import os
import threading

root = tk.Tk()
root.title("OMR Grading System")

root.geometry("600x600")
root.config(bg="#2E2E2E")

# Global variables
ans = []
input_method = ""
file_path = ""
score = 0
cap = None
current_img = None

# Function to get answers from the user
def submit_answers():
    global ans
    try:
        ans_entry = answer_entry.get()
        ans = [int(x) for x in ans_entry.split(",")]
        messagebox.showinfo("Success", "Answers submitted!")
    except ValueError:
        messagebox.showerror("Error", "Please enter valid answers (comma-separated integers)")

# Function to use webcam
def use_webcam():
    global input_method, cap
    input_method = "webcam"
    messagebox.showinfo("Info", "Webcam selected. Click 'Capture' to capture the OMR sheet.")

    if cap is None:
        cap = cv2.VideoCapture(0)
        threading.Thread(target=capture_frame).start()  # Start webcam capture in a separate thread

def capture_frame():
    global cap, current_img
    while True:
        ret, img = cap.read()
        if ret:
            current_img = img  # Store the current frame for capture
            cv2.imshow("Webcam Feed", img)  # Show the webcam feed
        if cv2.waitKey(1) & 0xFF == ord('q'):  # Press 'q' to exit the webcam feed
            break
    cap.release()
    cv2.destroyAllWindows()

# Function to capture the OMR sheet
def capture_omr():
    global current_img
    if current_img is not None:
        process_omr(current_img)
    else:
        messagebox.showerror("Error", "No image captured. Please click 'Capture' first.")

# Function to upload image file
def upload_file():
    global input_method, file_path
    input_method = "file"
    file_path = filedialog.askopenfilename(title="Select an Image", filetypes=[("Image Files", "*.jpg *.jpeg *.png")])
    if file_path:
        messagebox.showinfo("Info", f"File {file_path} selected. Press 'Start Grading' to begin.")

# Function to start the grading process
def start_grading():
    global input_method, ans, file_path, score
    img = None
    if input_method == "webcam":
        if current_img is None:
            messagebox.showerror("Error", "No image captured. Please click 'Capture' first.")
            return
        img = current_img
        cap.release()
        cv2.destroyAllWindows()
    elif input_method == "file":
        if file_path:
            img = cv2.imread(file_path)
        else:
            messagebox.showerror("Error", "Please upload a valid image file.")
            return
    else:
        messagebox.showerror("Error", "Please select an input method (Webcam or File).")
        return

    process_omr(img)
# Function to add labels on images
def put_label(img, label_text, position=(10, 50)):
    cv2.putText(img, label_text, position, cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)

# Function to stack images with labels
def stack_images(scale, imgArray, labels):
    rows = len(imgArray)
    cols = len(imgArray[0])
    rowsAvailable = isinstance(imgArray[0], list)
    width = imgArray[0][0].shape[1]
    height = imgArray[0][0].shape[0]

    if rowsAvailable:
        for x in range(0, rows):
            for y in range(0, cols):
                img = imgArray[x][y]
                if img.shape[:2] == imgArray[0][0].shape[:2]:
                    imgArray[x][y] = cv2.resize(img, (0, 0), None, scale, scale)
                else:
                    imgArray[x][y] = cv2.resize(img, (imgArray[0][0].shape[1], imgArray[0][0].shape[0]), None, scale, scale)
                if len(imgArray[x][y].shape) == 2:
                    imgArray[x][y] = cv2.cvtColor(imgArray[x][y], cv2.COLOR_GRAY2BGR)

                # Add labels to images
                put_label(imgArray[x][y], labels[x][y], (10, 50))

        imageBlank = np.zeros((height, width, 3), np.uint8)
        hor = [imageBlank] * rows
        for x in range(0, rows):
            hor[x] = np.hstack(imgArray[x])
        ver = np.vstack(hor)
    else:
        for x in range(0, rows):
            img = imgArray[x]
            if img.shape[:2] == imgArray[0].shape[:2]:
                imgArray[x] = cv2.resize(img, (0, 0), None, scale, scale)
            else:
                imgArray[x] = cv2.resize(img, (imgArray[0].shape[1], imgArray[0].shape[0]), None, scale, scale)
            if len(imgArray[x].shape) == 2:
                imgArray[x] = cv2.cvtColor(imgArray[x], cv2.COLOR_GRAY2BGR)

            # Add labels to images
            put_label(imgArray[x], labels[x], (10, 50))

        hor = np.hstack(imgArray)
        ver = hor
    return ver

# Function to process the OMR image and grade answers
def process_omr(img):
    global score
    try:
        heightImg = 700
        widthImg = 700
        questions = len(ans)
        choices = 5

        img = cv2.resize(img, (widthImg, heightImg))  # RESIZE IMAGE
        imgFinal = img.copy()
        imgGray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)  # CONVERT IMAGE TO GRAY SCALE
        imgBlur = cv2.GaussianBlur(imgGray, (5, 5), 1)  # ADD GAUSSIAN BLUR
        imgCanny = cv2.Canny(imgBlur, 10, 70)  # APPLY CANNY EDGE DETECTION

        contours, hierarchy = cv2.findContours(imgCanny, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)  # FIND CONTOURS
        rectCon = utlis.rectContour(contours)  # FILTER RECTANGLES
        biggestPoints = utlis.getCornerPoints(rectCon[0])  # GET THE BIGGEST RECTANGLE

        if biggestPoints.size != 0:
            biggestPoints = utlis.reorder(biggestPoints)
            pts1 = np.float32(biggestPoints)
            pts2 = np.float32([[0, 0], [widthImg, 0], [0, heightImg], [widthImg, heightImg]])
            matrix = cv2.getPerspectiveTransform(pts1, pts2)
            imgWarpColored = cv2.warpPerspective(img, matrix, (widthImg, heightImg))

            imgWarpGray = cv2.cvtColor(imgWarpColored, cv2.COLOR_BGR2GRAY)
            imgThresh = cv2.threshold(imgWarpGray, 170, 255, cv2.THRESH_BINARY_INV)[1]

            boxes = utlis.splitBoxes(imgThresh)
            myPixelVal = np.zeros((questions, choices))

            countR = 0
            countC = 0
            for image in boxes:
                totalPixels = cv2.countNonZero(image)
                myPixelVal[countR][countC] = totalPixels
                countC += 1
                if countC == choices:
                    countC = 0
                    countR += 1

            myIndex = []
            for x in range(0, questions):
                arr = myPixelVal[x]
                myIndexVal = np.where(arr == np.amax(arr))
                myIndex.append(myIndexVal[0][0])

            grading = []
            for x in range(0, questions):
                if ans[x] == myIndex[x]:
                    grading.append(1)
                else:
                    grading.append(0)

            score = (sum(grading) / questions) * 100

            # Stack all stages of the process
            imgContours = img.copy()
            cv2.drawContours(imgContours, contours, -1, (0, 255, 0), 10)

            # STACK ALL IMAGES TO SHOW THE PROCESS WITH LABELS
            imageArray = [[img, imgGray, imgBlur, imgCanny],
                          [imgContours, imgThresh, imgWarpColored, imgFinal]]

            labels = [["Original", "Grayscale", "Blurred", "Canny"],
                      ["Contours", "Threshold", "Warped", "Final"]]

            stackedImage = stack_images(0.5, imageArray, labels)
            cv2.imshow("Stacked Image Processing with Labels", stackedImage)

            # Display the final result with the grade
            messagebox.showinfo("Result", f"Your Score is: {score:.2f}%")
            save_results()
        else:
            messagebox.showerror("Error", "OMR sheet not detected.")
    except Exception as e:
        messagebox.showerror("Error", str(e))

# Function to save results to Excel
def save_results():
    name = name_entry.get()
    reg_number = reg_entry.get()
    hours_studied = hours_entry.get()
    group = group_entry.get()

    if not name or not reg_number or not hours_studied or not group:
        messagebox.showerror("Error", "Please enter all required fields.")
        return

    data = {
        "Name": [name],
        "Registration Number": [reg_number],
        "Score (%)": [score],
        "Hours Studied": [hours_studied],
        "Group": [group]
    }

    df = pd.DataFrame(data)

    # Define file path and check if it exists
    file_path = 'OMR_Results.xlsx'

    # Check if the file exists
    if os.path.exists(file_path):
        try:
            # Load existing data
            existing_df = pd.read_excel(file_path, sheet_name='Results')
            # Concatenate existing data with new data
            updated_df = pd.concat([existing_df, df], ignore_index=True)

            # Write the updated DataFrame back to Excel
            with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                updated_df.to_excel(writer, sheet_name='Results', index=False)
        except ValueError:
            # If the "Results" sheet does not exist, create it
            with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
                df.to_excel(writer, sheet_name='Results', index=False)
    else:
        # Create a new Excel file and write the DataFrame
        with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
            df.to_excel(writer, sheet_name='Results', index=False)

    messagebox.showinfo("Success", "Results saved successfully.")

capture_button = tk.Button(root, text="Capture OMR Sheet", command=capture_omr, bg="#FF5722", fg="#FFFFFF", font=("Helvetica", 12, "bold"))
capture_button.pack(pady=10)

# Labels and Input fields for the GUI
tk.Label(root, text="OMR Grading System", font=("Helvetica", 20, "bold"), fg="#FFFFFF", bg="#2E2E2E").pack(pady=20)

tk.Label(root, text="Enter Correct Answers (Comma Separated):", font=("Helvetica", 12), fg="#FFFFFF", bg="#2E2E2E").pack(pady=10)
answer_entry = tk.Entry(root, width=30, bg="#3C3C3C", fg="#FFFFFF", font=("Helvetica", 12))
answer_entry.pack(pady=10)

tk.Label(root, text="Enter Name:", font=("Helvetica", 12), fg="#FFFFFF", bg="#2E2E2E").pack(pady=10)
name_entry = tk.Entry(root, width=30, bg="#3C3C3C", fg="#FFFFFF", font=("Helvetica", 12))
name_entry.pack(pady=10)

tk.Label(root, text="Enter Registration Number:", font=("Helvetica", 12), fg="#FFFFFF", bg="#2E2E2E").pack(pady=10)
reg_entry = tk.Entry(root, width=30, bg="#3C3C3C", fg="#FFFFFF", font=("Helvetica", 12))
reg_entry.pack(pady=10)

tk.Label(root, text="Enter Hours Studied:", font=("Helvetica", 12), fg="#FFFFFF", bg="#2E2E2E").pack(pady=10)
hours_entry = tk.Entry(root, width=30, bg="#3C3C3C", fg="#FFFFFF", font=("Helvetica", 12))
hours_entry.pack(pady=10)

tk.Label(root, text="Enter Group:", font=("Helvetica", 12), fg="#FFFFFF", bg="#2E2E2E").pack(pady=10)
group_entry = tk.Entry(root, width=30, bg="#3C3C3C", fg="#FFFFFF", font=("Helvetica", 12))
group_entry.pack(pady=10)

submit_button = tk.Button(root, text="Submit Answers", command=submit_answers, bg="#4CAF50", fg="#FFFFFF", font=("Helvetica", 12, "bold"))
submit_button.pack(pady=10)

webcam_button = tk.Button(root, text="Use Webcam", command=use_webcam, bg="#2196F3", fg="#FFFFFF", font=("Helvetica", 12, "bold"))
webcam_button.pack(pady=10)

file_button = tk.Button(root, text="Upload Image", command=upload_file, bg="#FF9800", fg="#FFFFFF", font=("Helvetica", 12, "bold"))
file_button.pack(pady=10)

start_button = tk.Button(root, text="Start Grading", command=start_grading, bg="#F44336", fg="#FFFFFF", font=("Helvetica", 12, "bold"))
start_button.pack(pady=20)

root.mainloop()